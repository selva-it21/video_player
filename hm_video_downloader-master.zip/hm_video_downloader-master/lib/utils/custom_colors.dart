import 'package:flutter/material.dart';

class CustomColors {
  static Color get backGround => const Color(0xFF121212);
  static Color get appBar => const Color(0xFF212121);
  static Color get primary => Colors.blue;
  static Color get white => Colors.white;
}
